# digitalbanking Loan Microservice
Digital Banking Training

mvn clean install
Run application.java from com.capg.loanservices package

This is a spring boot application
It will run embedded tomcat container.

To run
java –jar loanservices-1.0.jar

To test, start postman app in chrome
http://localhost:8080/loanservice/1/loans

You have to create db_loan database in postgresql.
Use sql scripts to create the tables and insert the data.

