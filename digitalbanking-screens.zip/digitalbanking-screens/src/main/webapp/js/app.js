'use strict';

/* App Module */
var digitalbankingApp = angular.module(
		'digitalbankingApp',
		[ 'routes','ngGrid', 				
				'digitalbankingServices', 'digitalbankingControllers', 'digitalbankingDirectives', 'ngInputModified', 'ngProgress','ngStorage'
				]);
